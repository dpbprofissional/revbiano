import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Check, Copy, Loader2, Smartphone, Zap, ShieldCheck, Clock } from "lucide-react";

type Carrier = "claro" | "vivo" | "tim";

const PRICING: Record<Carrier, { recharge: number; price: number }[]> = {
  claro: [
    { recharge: 20, price: 15 },
    { recharge: 25, price: 19 },
    { recharge: 30, price: 22 },
    { recharge: 50, price: 37 },
    { recharge: 100, price: 74 },
  ],
  vivo: [
    { recharge: 15, price: 13 },
    { recharge: 20, price: 16 },
    { recharge: 25, price: 20 },
    { recharge: 30, price: 23 },
    { recharge: 50, price: 39 },
    { recharge: 100, price: 78 },
  ],
  tim: [
    { recharge: 15, price: 10.5 },
    { recharge: 20, price: 14 },
    { recharge: 25, price: 17.5 },
    { recharge: 30, price: 21 },
    { recharge: 50, price: 35 },
    { recharge: 100, price: 70 },
  ],
};

const CARRIER_META: Record<Carrier, { label: string; color: string; emoji: string }> = {
  claro: { label: "Claro", color: "carrier-claro", emoji: "🔴" },
  vivo:  { label: "Vivo",  color: "carrier-vivo",  emoji: "🟣" },
  tim:   { label: "Tim",   color: "carrier-tim",   emoji: "🔵" },
};

const fmt = (n: number) =>
  n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const formatPhone = (raw: string) => {
  const v = raw.replace(/\D/g, "").slice(0, 11);
  if (v.length <= 2) return v;
  if (v.length <= 7) return `(${v.slice(0,2)}) ${v.slice(2)}`;
  if (v.length <= 10) return `(${v.slice(0,2)}) ${v.slice(2,6)}-${v.slice(6)}`;
  return `(${v.slice(0,2)}) ${v.slice(2,7)}-${v.slice(7)}`;
};

const Index = () => {
  const [carrier, setCarrier] = useState<Carrier>("claro");
  const [selected, setSelected] = useState<{ recharge: number; price: number } | null>(null);
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [payment, setPayment] = useState<{
    order_id: string;
    qr_code: string;
    qr_image_url: string;
    amount: number;
    expires_at: string;
  } | null>(null);
  const [paid, setPaid] = useState(false);

  // Poll status when payment is open
  useEffect(() => {
    if (!payment || paid) return;
    const interval = setInterval(async () => {
      const { data } = await supabase
        .from("orders")
        .select("status")
        .eq("id", payment.order_id)
        .maybeSingle();
      if (data?.status === "completed" || data?.status === "fulfilled") {
        setPaid(true);
        toast.success("Pagamento confirmado! Sua recarga será feita em instantes 🎉");
        clearInterval(interval);
      } else if (data?.status === "expired" || data?.status === "cancelled") {
        toast.error("Pagamento expirado. Gere um novo PIX.");
        setPayment(null);
        clearInterval(interval);
      }
    }, 4000);
    return () => clearInterval(interval);
  }, [payment, paid]);

  const handleSubmit = async () => {
    if (!selected) return toast.error("Escolha um valor de recarga");
    const clean = phone.replace(/\D/g, "");
    if (clean.length < 10 || clean.length > 11) return toast.error("Telefone inválido");

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("create-payment", {
        body: { carrier, phone: clean, recharge_amount: selected.recharge },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setPayment(data);
      setPaid(false);
    } catch (e: any) {
      toast.error(e.message || "Erro ao gerar pagamento");
    } finally {
      setLoading(false);
    }
  };

  const copyPix = () => {
    if (!payment) return;
    navigator.clipboard.writeText(payment.qr_code);
    toast.success("Código PIX copiado!");
  };

  const reset = () => {
    setPayment(null);
    setPaid(false);
    setSelected(null);
    setPhone("");
  };

  if (payment) {
    return (
      <main className="min-h-screen flex items-center justify-center px-4 py-10">
        <Card className="card-elevated w-full max-w-md p-8 border-border/50">
          {paid ? (
            <div className="text-center space-y-5">
              <div className="mx-auto w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center glow">
                <Check className="w-10 h-10 text-primary" strokeWidth={3} />
              </div>
              <h2 className="text-3xl font-bold text-gradient">Pagamento confirmado!</h2>
              <p className="text-muted-foreground">
                Sua recarga será processada manualmente e creditada em até alguns minutos no número informado.
              </p>
              <Button onClick={reset} variant="default" size="lg" className="w-full">
                Fazer outra recarga
              </Button>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="text-center space-y-1">
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Pague com PIX</p>
                <p className="text-4xl font-bold text-gradient">{fmt(payment.amount)}</p>
              </div>
              <div className="bg-white p-4 rounded-2xl flex items-center justify-center">
                <img src={payment.qr_image_url} alt="QR Code PIX" className="w-full max-w-[260px]" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-2">PIX copia e cola:</p>
                <div className="flex gap-2">
                  <Input value={payment.qr_code} readOnly className="font-mono text-xs" />
                  <Button onClick={copyPix} variant="secondary" size="icon">
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                Aguardando confirmação do pagamento...
              </div>
              <Button onClick={reset} variant="ghost" className="w-full">
                Cancelar
              </Button>
            </div>
          )}
        </Card>
      </main>
    );
  }

  return (
    <main className="min-h-screen px-4 py-10">
      <div className="max-w-2xl mx-auto space-y-10">
        <header className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium">
            <Zap className="w-3 h-3" /> RECARGA INSTANTÂNEA VIA PIX
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight">
            Recarregue seu celular com <span className="text-gradient">até 30% off</span>
          </h1>
          <p className="text-muted-foreground">
            Escolha sua operadora, pague com PIX e receba seu crédito.
          </p>
        </header>

        <Card className="card-elevated p-6 sm:p-8 border-border/50 space-y-6">
          {/* Carrier */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">1. Operadora</label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(CARRIER_META) as Carrier[]).map((c) => {
                const m = CARRIER_META[c];
                const active = carrier === c;
                return (
                  <button
                    key={c}
                    onClick={() => { setCarrier(c); setSelected(null); }}
                    className={`relative py-4 rounded-xl border-2 font-semibold transition-all ${
                      active
                        ? `border-[hsl(var(--${m.color}))] bg-[hsl(var(--${m.color})/0.15)] text-foreground`
                        : "border-border bg-secondary/40 text-muted-foreground hover:border-border/80"
                    }`}
                  >
                    <span className="text-lg mr-1">{m.emoji}</span>
                    {m.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amount */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">2. Valor da recarga</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {PRICING[carrier].map((opt) => {
                const active = selected?.recharge === opt.recharge;
                const discount = Math.round((1 - opt.price / opt.recharge) * 100);
                return (
                  <button
                    key={opt.recharge}
                    onClick={() => setSelected(opt)}
                    className={`relative p-4 rounded-xl border-2 text-left transition-all ${
                      active
                        ? "border-primary bg-primary/10 glow"
                        : "border-border bg-secondary/40 hover:border-border/80"
                    }`}
                  >
                    <div className="absolute top-2 right-2 text-[10px] font-bold px-1.5 py-0.5 rounded bg-primary/20 text-primary">
                      -{discount}%
                    </div>
                    <div className="text-xs text-muted-foreground">Recebe</div>
                    <div className="text-xl font-bold">R$ {opt.recharge}</div>
                    <div className="text-xs text-muted-foreground mt-1">Você paga</div>
                    <div className="text-base font-semibold text-primary">{fmt(opt.price)}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Phone */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">3. Número do celular</label>
            <div className="relative">
              <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                value={phone}
                onChange={(e) => setPhone(formatPhone(e.target.value))}
                placeholder="(11) 99999-9999"
                inputMode="numeric"
                className="pl-10 h-12 text-base"
              />
            </div>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={loading || !selected || !phone}
            size="lg"
            className="w-full h-14 text-base font-bold bg-gradient-to-r from-primary to-[hsl(var(--primary-glow))] hover:opacity-90 text-primary-foreground"
          >
            {loading ? (
              <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Gerando PIX...</>
            ) : selected ? (
              <>Pagar {fmt(selected.price)} via PIX</>
            ) : (
              "Selecione um valor"
            )}
          </Button>
        </Card>

        <div className="grid grid-cols-3 gap-3 text-center">
          {[
            { icon: Zap, label: "Rápido", desc: "Até 5 min" },
            { icon: ShieldCheck, label: "Seguro", desc: "Pagamento PIX" },
            { icon: Clock, label: "24/7", desc: "Sempre on" },
          ].map((f) => (
            <div key={f.label} className="p-4 rounded-xl border border-border/50 bg-secondary/20">
              <f.icon className="w-5 h-5 mx-auto mb-2 text-primary" />
              <div className="text-sm font-semibold">{f.label}</div>
              <div className="text-xs text-muted-foreground">{f.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
};

export default Index;
